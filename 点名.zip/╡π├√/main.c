#include <stdio.h> 
#include "acllib.h"
#include <stdlib.h> 
#define SN 6

struct student
{
	int num;
	char sno[10];
	char name[10];
}stu[SN];

void mouseListener();
int a;
int Setup()
{
	initWindow("test",100,100,500,500);
	beginPaint();
	setTextSize(80);
	paintText(170,30,"����"); 
	endPaint();
	FILE *fp;
	int i;
	if((fp=fopen("stu.txt","r"))!=NULL)
	{
		for(i=0;i<SN;i++)
		{
			fscanf(fp,"%d%s%s",&stu[i].num,stu[i].sno,stu[i].name);
		}
		fclose(fp);
	}
	registerMouseEvent(mouseListener);
	
	return 0;
}

void mouseListener(int x,int y,int button,int event)
{
	if(button==1&&event==0)
	{
		srand(time(NULL));
		a=rand()%SN;
		beginPaint();
		setTextColor(BLUE);
		setTextSize(90);
		setTextBkColor(YELLOW);
		paintText(130,150,stu[a].name); 
		paintText(80,300,stu[a].sno); 
		endPaint();
	}	
}
