#include "acllib.h"
#include <stdio.h>

#define A11 125,125
#define A12 275,125
#define A13 425,125
#define A21 125,275
#define A22 275,275
#define A23 425,275
#define A31 125,425
#define A32 275,425
#define A33 425,425

void blueCS();//���������� 
void redCS();//���췽����
int judge();//�ж���Ӯ
void mouseListener();

//���̾����ʼ�� 
int board[3][3]={{0,0,0},{0,0,0},{0,0,0}};

int Setup()
{
	initWindow("test",100,100,550,650);//�������� 
	//������
	beginPaint();
	setPenWidth(5);
	line(50,50,50,500);
	line(50,50,500,50);
	line(500,50,500,500);
	line(50,500,500,500);
	line(50,200,500,200);
	line(50,350,500,350);
	line(200,50,200,500);
	line(350,50,350,500);
	setTextColor(GREEN);
	setTextSize(80);
	paintText(150,550,"������"); 
	endPaint();
	
	//������� 
	registerMouseEvent(mouseListener);
	
	return 0;
}

void blueCS(int m,int n)
{
	beginPaint();
	setPenWidth(3);
	setBrushColor(BLUE);
	ellipse(m-45,n-45,m+45,n+45);
	endPaint();
}

void redCS(int m,int n)
{
	beginPaint();
	setPenWidth(3);
	setBrushColor(RED);
	ellipse(m-45,n-45,m+45,n+45);
	endPaint();
}

void mouseListener(int x,int y,int button,int event)
{
	//λ�÷���
	static int cnt=1; 
	int xy,rst=0;
	if (x>50&&x<200&&y>50&&y<200)
	{
		xy=11;
	}else if (x>50&&x<200&&y>200&&y<350)
	{
		xy=21;
	}else if (x>50&&x<200&&y>350&&y<500)
	{
		xy=31;
	}else if (200&&x<350&&y>50&&y<200)
	{
		xy=12;
	}else if (200&&x<350&&y>200&&y<350)
	{
		xy=22;
	}else if (200&&x<350&&y>350&&y<500)
	{
		xy=32;
	}else if (350&&x<500&&y>50&&y<200)
	{
		xy=13;
	}else if (x>350&&x<500&&y>200&&y<350)
	{
		xy=23;
	}else if (x>350&&x<500&&y>350&&y<500)
	{
		xy=33;
	}
	//�жϵ��λ�ò����� 
	while(rst!=1&&rst!=2&&rst!=-1)
	{
		if(button==1&&event==0)
		{
			switch(xy)
			{
				case 11:if(cnt%2==1){redCS(A11);board[0][0]=1;}else if(cnt%2==0){blueCS(A11);board[0][0]=2;};
				break;
				case 12:if(cnt%2==1){redCS(A12);board[0][1]=1;}else if(cnt%2==0){blueCS(A12);board[0][1]=2;};
				break;
				case 13:if(cnt%2==1){redCS(A13);board[0][2]=1;}else if(cnt%2==0){blueCS(A13);board[0][2]=2;};
				break;
				case 21:if(cnt%2==1){redCS(A21);board[1][0]=1;}else if(cnt%2==0){blueCS(A21);board[1][0]=2;};
				break;
				case 22:if(cnt%2==1){redCS(A22);board[1][1]=1;}else if(cnt%2==0){blueCS(A22);board[1][1]=2;};
				break;
				case 23:if(cnt%2==1){redCS(A23);board[1][2]=1;}else if(cnt%2==0){blueCS(A23);board[1][2]=2;};
				break;			
				case 31:if(cnt%2==1){redCS(A31);board[2][0]=1;}else if(cnt%2==0){blueCS(A31);board[2][0]=2;};
				break;
				case 32:if(cnt%2==1){redCS(A32);board[2][1]=1;}else if(cnt%2==0){blueCS(A32);board[2][1]=2;};
				break;
				case 33:if(cnt%2==1){redCS(A33);board[2][2]=1;}else if(cnt%2==0){blueCS(A33);board[2][2]=2;};
				break;			
				
			}
			cnt++;
		}
		rst=judge(*board);
		
		//��ӡ��� 
		beginPaint();
		setTextColor(CYAN);
		setTextBkColor(YELLOW);
		setTextSize(100);
		switch(rst)
		{
			case 1:paintText(100,215,"�췽ʤ!");break;
			case 2:paintText(100,215,"����ʤ!");break;
			case -1:paintText(150,215,"ƽ��!");break;
			case 0:break;
		}
		endPaint();
	}
}

int judge(int bd[3][3])
{
	int rst=0,i,j,numB,numR;
	for(i=0;i<3;i++)         //�ж������Ƿ�����  0δ������-1�� 
	{
		for(j=0;j<3;j++)
		{
			if(bd[i][j]!=0)
			rst=-1;
		}
	}
	
	for(i=0;i<3;i++)         //����� 
	{
		numB=numR=0;
		for(j=0;j<3;j++)
		{
		 	if(bd[i][j]==1){
		 		numR++;
		 	}else if(bd[i][j]==2){
		 		numB++;
			 }
		}
		if(numR==3){
			rst=1;
		}else if(numB==3){
			rst=2;
		}
	}
	
	if(rst==0||rst==-1){          //����� 
		for(j=0;j<3;j++)
		{
			numB=numR=0;
			for(i=0;i<3;i++)
			{
			 	if(bd[i][j]==1){
			 		numR++;
			 	}else if(bd[i][j]==2){
			 		numB++;
				}
			}
			if(numR==3){
				rst=1;
			}else if(numB==3){
				rst=2;
			}
		}

	}
	if(rst==0||rst==-1){          //���Խ��� 
		numB=numR=0;
		for(i=0;i<3;i++)
		{
		 	if(bd[i][i]==1){
		 		numR++;
		 	}else if(bd[i][i]==2){
		 		numB++;
			}
		}
		if(numR==3){
			rst=1;
		}else if(numB==3){
			rst=2;
		}
		numB=numR=0;

		for(i=0;i<3;i++)
		{
		 	if(bd[i][2-i]==1){
		 		numR++;
		 	}else if(bd[i][2-i]==2){
		 		numB++;
			}
		}
		if(numR==3){
			rst=1;
		}else if(numB==3){
			rst=2;
		}
		
	}
	
	return rst;// 1��ʤ 2��ʤ -1����ʤ 0δʤ 
}



